/** Automatically generated file. DO NOT MODIFY */
package com.the4960development.patrum;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}