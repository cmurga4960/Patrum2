package com.the4960development.patrum;

public class Note
{
	final static int e = 0;
	final static int ef = 0;
	
	final static int f = 1;
	final static int fs = 1;
	
	final static int g = 2;
	final static int gs= 2;
	final static int gf = 2;
	
	final static int a = 3;
	final static int as = 3;
	final static int af = 3;
	
	final static int b = 4;
	final static int bf = 4;
	
	final static int c = 5;
	final static int cs = 5;
	final static int cf = 5;
	
	final static int d = 6;
	final static int ds = 6;
	final static int df = 6;
	
	final static int e2 = 7;
	final static int ef2 = 7;
	
	final static int f2 = 8;
	final static int fs2 = 8;
	final int letters[] = {e,ef,f,fs,g,gs,gf,a,as,af,b,bf,c,cs,cf,d,ds,df,e2,ef2,f2,fs2};
	
	final static double eigth = 1/2;
	final static double quater = 1;
	final static double half = 2;
	final static double whole = 4;
	final double lenghts[] = {eigth,quater,half,whole};
	
	public int letter=-1;
	public double lenght=-1;
	
	public Note(int letter, double lenght) throws Exception
	{
		for(int i : letters)
			if(letter == i)
				this.letter = letter;
		if(this.letter==-1)
			throw new Exception("Bad Letter");
		for(double i : lenghts)
			if(lenght == i)
				this.lenght = lenght;
		if(this.lenght==-1)
			throw new Exception("Bad Lenght");
	}
}