package com.the4960development.patrum;

public class Song
{
	public int id;
	public String title;
	public int[] time_sig = {4,4};
	public Note[][] notes;
	public int num_notes;
	public int tempo = 120;
	
	public Song(){}
	
	public Song(int id, String title, int [] time_sig, Note notes[][], int tempo)
	{
		this.id=id;
		this.title=title;
		this.notes=notes;
		this.tempo=tempo;
		if(time_sig!=null)
			if(time_sig.length==2)
				this.time_sig=time_sig;
		if(notes!=null)
			this.num_notes = notes.length;
		else
			this.num_notes = 0;
	}
	
	@Override
	public String toString()
	{
		return "id: "+id+
				"Title: "+title+
				", Num notes: "+num_notes+
				", Tempo: "+tempo;
	}
	
}