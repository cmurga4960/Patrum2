package com.the4960development.patrum;

public interface MusicListener
{

}
